package kangwon.cse1.sms.dailylook;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class LoginActivity extends AppCompatActivity {

    Button BirthButton;
    Button DailyButton;
    EditText idText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        BirthButton = (Button) findViewById(R.id.birthButton);
        DailyButton = (Button) findViewById(R.id.dailyButton);
        idText = (EditText) findViewById(R.id.idText);

        BirthButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                birth();
            }
        });

        DailyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                daily();
            }
        });

        Intent intent = getIntent();
        String userID = intent.getStringExtra("userID");
        String userPassword = intent.getStringExtra("userPassword");

        String message = "환영합니다 " + userID + " 님!";
        Toast.makeText(LoginActivity.this,message,Toast.LENGTH_SHORT).show();
    }
    public static boolean isIntentAvailable(Context context,String action) { //카메라 권한 가져오기
        final PackageManager packageManager = context.getPackageManager();
        final Intent intent = new Intent(action);
        List<ResolveInfo> list = packageManager.queryIntentActivities(intent,PackageManager.MATCH_DEFAULT_ONLY);
        return list.size() > 0;
    }
    private void dispatchTakePictureIntent(int actionCode) { //권한을 가져온 카메라를 이 액티비티에 실행시킨다.
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if(isIntentAvailable(getApplicationContext(),MediaStore.ACTION_IMAGE_CAPTURE)) {
            startActivityForResult(takePictureIntent,actionCode);
        }
    }
    private void handleSmallCameraPhoto(Intent intent) {
        Bundle bundle = intent.getExtras();
        mImageBitmap
    }

    public void birth() {
        Toast.makeText(this,"기념일이 예약되었어요!",Toast.LENGTH_SHORT).show();
    }
    public void daily() {
        Toast.makeText(this,"오늘의 DailyLook을 전송합니다.",Toast.LENGTH_SHORT).show();
    }

}

