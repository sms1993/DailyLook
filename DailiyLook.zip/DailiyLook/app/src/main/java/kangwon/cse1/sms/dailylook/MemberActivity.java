package kangwon.cse1.sms.dailylook;

import android.content.Intent;
import android.support.annotation.IdRes;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class MemberActivity extends AppCompatActivity {

    int Count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_member);

        String[] str = getResources().getStringArray(R.array.area);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_dropdown_item, str
        );
        String[] str1 = getResources().getStringArray(R.array.gender);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_dropdown_item, str1
        );
        //스피너 를 String으로 나열하는 작업
        Spinner spinnerArray = (Spinner) findViewById(R.id.spinnerArray);
        Spinner genderrArray = (Spinner) findViewById(R.id.genderArray);
        spinnerArray.setAdapter(adapter);
        genderrArray.setAdapter(adapter1);
        spinnerArray.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        print(view, position);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                }
        );
        genderrArray.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        print1(view, position);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                }
        );

        Button saveButton = (Button)findViewById(R.id.saveButton);
        Button cancelButton = (Button)findViewById(R.id.cancelButton);
        Button searchButton = (Button)findViewById(R.id.searchButton);

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancel();
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
            }
        });


        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search();
            }
        });
    }

        public void print(View v, int position) {
            Spinner sp = (Spinner)findViewById(R.id.spinnerArray);
            String res = "";
            if(sp.getSelectedItemPosition() > 0) {
              res = (String)sp.getAdapter().getItem(sp.getSelectedItemPosition());
            }
        }
        public void print1(View v, int position) {
            Spinner sp1 = (Spinner)findViewById(R.id.genderArray);
            String res1 = "";
            if(sp1.getSelectedItemPosition() > 0) {
                res1 = (String)sp1.getAdapter().getItem(sp1.getSelectedItemPosition());
            }
        }
        public void search() {

            EditText pwText = (EditText)findViewById(R.id.pwText);
            EditText pwSearchText = (EditText)findViewById(R.id.pwSearchText);

            if(!(pwText.getText().toString().equals(pwSearchText.getText().toString()))) {
                Toast.makeText(this,"비밀번호를 확인해주세요.",Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this,"비밀번호가 일치합니다.",Toast.LENGTH_SHORT).show();
                Count++;
            }
        }
        public void save() {

            final EditText idText = (EditText)findViewById(R.id.idText);
            final EditText pwText = (EditText)findViewById(R.id.pwText);
            EditText pwSearchText = (EditText)findViewById(R.id.pwSearchText);
            final EditText nameText = (EditText)findViewById(R.id.nameText);
            final EditText EmailText = (EditText)findViewById(R.id.EmailText);
            final Spinner spinnerArray = (Spinner)findViewById(R.id.spinnerArray);
            final Spinner genderArray = (Spinner)findViewById(R.id.genderArray);

            if(idText.getText().toString().equals("")) {
                Toast.makeText(this,"아이디를 입력하지않으셨습니다.",Toast.LENGTH_SHORT).show();
            }
            else if(pwText.getText().toString().equals("")) {
                Toast.makeText(this,"비밀번호를 입력하지않으셨습니다..",Toast.LENGTH_SHORT).show();
            }
            else if(Count == 0) {
                Toast.makeText(this,"비밀번호를 확인하지않으셨습니다..",Toast.LENGTH_SHORT).show();
            }
            else if(nameText.getText().toString().equals("")) {
                Toast.makeText(this,"이름을 입력하지않았습니다.",Toast.LENGTH_SHORT).show();
            }
            else if(EmailText.getText().toString().equals("")) {
                Toast.makeText(this,"이메일을 입력하지않았습니다.",Toast.LENGTH_SHORT).show();
            }
            else if(genderArray.getSelectedItem().toString().equals("[성별선택]")) {
                Toast.makeText(this,"성별을 입력하지않았습니다." ,Toast.LENGTH_SHORT).show();
            }
            else if(spinnerArray.getSelectedItem().toString().equals("[지역선택]")) {
                Toast.makeText(this,"지역을 입력하지않았습니다.",Toast.LENGTH_SHORT).show();
            }
            else {
                final String userID = idText.getText().toString();
                final String userPassword = pwText.getText().toString();
                final String userName = nameText.getText().toString();
                final String userEmail = EmailText.getText().toString();
                final String userGender = genderArray.getSelectedItem().toString();
                final String userArea = spinnerArray.getSelectedItem().toString();

                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");
                            if(success) {
                                Toast.makeText(MemberActivity.this,"회원가입을 축하합니다.",Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(MemberActivity.this, MainActivity.class);
                                MemberActivity.this.startActivity(intent);
                                finish();
                            } else {
                                AlertDialog.Builder builder = new AlertDialog.Builder(MemberActivity.this);
                                builder.setMessage("회원가입에 실패하였습니다.").setNegativeButton("다시시도",null).create().show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };
                MemberRequest memberRequest = new MemberRequest(userID,userPassword,userName,userEmail,userGender,userArea, responseListener);
                RequestQueue queue = Volley.newRequestQueue(MemberActivity.this);
                queue.add(memberRequest);
            }
        }

        public void cancel() {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            Toast.makeText(this,"취소하셨습니다.",Toast.LENGTH_SHORT).show();
            startActivity(intent);
            finish();
        }

}

